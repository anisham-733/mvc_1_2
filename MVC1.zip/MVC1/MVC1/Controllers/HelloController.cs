﻿using Microsoft.AspNetCore.Mvc;

namespace MVC1.Controllers
{
    public class HelloController : Controller
    {
        public string Index()
        {
            //controller method will give string of HTML
            //http://localhost:port/Hello
            return "Hello";
        }
        public string welcome()
        {
            //https://localhost:7170/Hello/welcome
            return "Next page. Hi";
        }
    }
}
